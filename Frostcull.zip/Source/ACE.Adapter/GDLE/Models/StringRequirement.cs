namespace ACE.Adapter.GDLE.Models
{
    public class StringRequirement
    {
        public int Unknown { get; set; }
        public int OperationType { get; set; }
        public int Stat { get; set; }
        public string Value { get; set; }
    }
}
