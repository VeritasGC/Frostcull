
namespace ACE.Entity.Enum
{
    public enum HouseStatus
    {
        Disabled = -1,
        InActive,
        Active
    }
}
