using System;

namespace ACE.Entity.Enum
{
    [Flags]
    public enum AnimationFlags
    {
        PosFrames = 0x1
    }
}
