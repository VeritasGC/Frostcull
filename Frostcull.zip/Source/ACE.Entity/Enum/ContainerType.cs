﻿namespace ACE.Entity.Enum
{
    public enum ContainerType
    {
        NonContainer = 0,
        Container    = 1,
        Foci         = 2
    }
}
