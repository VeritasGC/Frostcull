namespace ACE.Entity.Enum
{
    public enum DelayedActionType
    {
        Start,
        Move,
        MovePass,
        Stalemate,
        Quit
    }
}
