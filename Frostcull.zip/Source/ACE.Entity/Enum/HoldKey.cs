namespace ACE.Entity.Enum
{
    public enum HoldKey: uint
    {
        Invalid     = 0x0,
        None        = 0x1,
        Run         = 0x2
    };
}
