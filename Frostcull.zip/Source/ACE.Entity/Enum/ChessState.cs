namespace ACE.Entity.Enum
{
    public enum ChessState
    {
        WaitingForPlayers,
        InProgress,
        Finished
    }
}
