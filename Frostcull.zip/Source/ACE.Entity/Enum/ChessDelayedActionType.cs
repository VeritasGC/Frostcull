namespace ACE.Entity.Enum
{
    public enum ChessDelayedActionType
    {
        Start,
        Move,
        MovePass,
        Stalemate,
        Quit
    }
}
