namespace ACE.Entity.Enum
{
    public enum FellowUpdateType
    {
        Undef,
        Full,
        Stats,
        Vitals
    };
}
