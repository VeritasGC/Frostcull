namespace ACE.Entity.Enum
{
    public enum ChessPieceType
    {
        Empty,
        Pawn,
        Rook,
        Knight,
        Bishop,
        Queen,
        King,
        Count
    }
}
