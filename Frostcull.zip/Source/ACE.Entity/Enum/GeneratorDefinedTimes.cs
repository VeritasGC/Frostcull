namespace ACE.Entity.Enum
{
    public enum GeneratorDefinedTimes
    {
        Undef,
        Dusk,
        Dawn
    }
}
