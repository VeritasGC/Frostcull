namespace ACE.Entity.Enum
{
    public enum CloakStatus
    {
        Undef,
        Off,
        On,
        Player,
        Creature
    }
}
