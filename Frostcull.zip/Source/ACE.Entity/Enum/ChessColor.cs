namespace ACE.Entity.Enum
{
    public enum ChessColor
    {
        None = -1,
        White = 0,
        Black = 1,
    }
}
