
namespace ACE.Entity.Enum
{
    public enum BondedStatus
    {
        Destroy     = -2,
        Slippery    = -1,
        Normal      = 0,
        Bonded      = 1,
        Sticky      = 2
    }
}
