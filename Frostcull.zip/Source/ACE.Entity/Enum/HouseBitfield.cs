using System;

namespace ACE.Entity.Enum
{
    [Flags]
    public enum HouseBitfield
    {
        Undef,
        Active,
        RequiresMonarch
    }
}
