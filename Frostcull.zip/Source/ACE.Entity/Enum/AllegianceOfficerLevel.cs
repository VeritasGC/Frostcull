namespace ACE.Entity.Enum
{
    public enum AllegianceOfficerLevel: uint
    {
        Undef     = 0,
        Speaker   = 1,
        Seneschal = 2,
        Castellan = 3
    }
}
