namespace ACE.Entity.Enum
{
    /// <summary>
    /// The type of spells to dispel
    /// </summary>
    public enum DispelType
    {
        All,
        Positive,
        Negative
    }
}
