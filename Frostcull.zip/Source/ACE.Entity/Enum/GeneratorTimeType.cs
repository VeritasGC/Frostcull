namespace ACE.Entity.Enum
{
    public enum GeneratorTimeType
    {
        Undef,
        RealTime,
        Defined,
        Event,
        Night,
        Day
    }
}
