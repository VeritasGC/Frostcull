using System;
using System.Collections.Generic;
using System.Text;

namespace ACE.Entity.Enum
{
    public enum ChatType
    {
        Undef,
        Allegiance,
        General,
        Trade,
        LFG,
        Roleplay,
        Society,
        SocietyCelHan,
        SocietyEldWeb,
        SocietyRadBlo,
        Olthoi
    }
}
