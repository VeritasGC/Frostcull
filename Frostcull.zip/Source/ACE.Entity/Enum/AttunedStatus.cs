
namespace ACE.Entity.Enum
{
    public enum AttunedStatus
    {
        Normal,
        Attuned,
        Sticky
    }
}
