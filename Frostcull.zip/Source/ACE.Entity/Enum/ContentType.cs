namespace ACE.Entity.Enum
{
    public enum ContentType
    {
        Patch = 1,

        Quest = 2
    }
}
