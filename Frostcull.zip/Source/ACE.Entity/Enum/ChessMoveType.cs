namespace ACE.Entity.Enum
{
    public enum ChessMoveType
    {
        Invalid,
        Pass,
        Resign,
        Stalemate,
        Grid,
        FromTo,
        SelectedPiece
    }
}
