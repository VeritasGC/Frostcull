namespace ACE.Entity.Enum
{
    public enum EndTradeReason
    {
        Normal = 0x1,
        EnteredCombat = 0x2,
        Canceled = 0x51
    };
}
