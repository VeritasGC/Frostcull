namespace ACE.Entity
{
    public class AnimationPartChange
    {
        public byte PartIndex { get; set; }
        public uint PartID { get; set; }
    }
}
