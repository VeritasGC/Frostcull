using System;
using System.IO;

using ACE.Entity.Enum;

namespace ACE.Entity
{
    public class BSPTree
    {
        public BSPNode RootNode { get; set; }
    }
}
